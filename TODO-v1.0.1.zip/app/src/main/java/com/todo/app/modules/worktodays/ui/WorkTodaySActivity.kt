package com.todo.app.modules.worktodays.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import com.todo.app.R
import com.todo.app.appcomponents.base.BaseActivity
import com.todo.app.databinding.ActivityWorkTodaySBinding
import com.todo.app.modules.wishlist.ui.WishListActivity
import com.todo.app.modules.worktodays.`data`.model.WorkTodayS1RowModel
import com.todo.app.modules.worktodays.`data`.viewmodel.WorkTodaySVM
import kotlin.Int
import kotlin.String
import kotlin.Unit

public class WorkTodaySActivity :
    BaseActivity<ActivityWorkTodaySBinding>(R.layout.activity_work_today_s) {
  private val viewModel: WorkTodaySVM by viewModels<WorkTodaySVM>()

  public override fun setUpClicks(): Unit {
    binding.btnMakeAWishLis.setOnClickListener {

      val destIntent = WishListActivity.getIntent(this, null)
      startActivity(destIntent)

    }
  }

  public fun onClickRecyclerView(
    view: View,
    position: Int,
    item: WorkTodayS1RowModel
  ): Unit {
    when(view.id) {


    }
  }

  public override fun onInitialized(): Unit {
    val recyclerViewAdapter =
                            RecyclerViewAdapter(viewModel.recyclerViewList.value?:mutableListOf())
    binding.recyclerView.adapter = recyclerViewAdapter
    recyclerViewAdapter.setOnItemClickListener(
                    object : RecyclerViewAdapter.OnItemClickListener {
                        override fun onItemClick(view:View, position:Int, item :
        WorkTodayS1RowModel) {
                            onClickRecyclerView(view, position, item)
                        }
                    }
                    )
    viewModel.recyclerViewList.observe(this) {
                        recyclerViewAdapter.updateData(it)
                    }
    binding.workTodaySVM = viewModel
  }

  public companion object {
    public const val TAG: String = "WORK_TODAY_S_ACTIVITY"

    public fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, WorkTodaySActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
