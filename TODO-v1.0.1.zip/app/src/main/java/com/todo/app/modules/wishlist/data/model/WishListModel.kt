package com.todo.app.modules.wishlist.`data`.model

import com.todo.app.R
import com.todo.app.appcomponents.di.MyApp
import kotlin.String

public data class WishListModel(
  /**
   * TODO Replace with dynamic value
   */
  public var txtMakeAWishLis: String? =
      MyApp.getInstance().resources.getString(R.string.msg_make_a_wish_lis)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMakeAWishLis1: String? =
      MyApp.getInstance().resources.getString(R.string.msg_make_a_wish_lis)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var txtMakeYourJobE: String? =
      MyApp.getInstance().resources.getString(R.string.msg_make_your_job_e)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var etTaskTodoValue: String? =
      MyApp.getInstance().resources.getString(R.string.msg_create_action_m)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var etDateValue: String? = MyApp.getInstance().resources.getString(R.string.lbl_tt_mm_yy)
  ,
  /**
   * TODO Replace with dynamic value
   */
  public var etAttachmentsValue: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_maximum_10_mb)

)
