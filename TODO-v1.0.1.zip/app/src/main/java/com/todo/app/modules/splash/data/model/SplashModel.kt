package com.todo.app.modules.splash.`data`.model

public class SplashModel()
