package com.todo.app.modules.home.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.todo.app.R
import com.todo.app.appcomponents.base.BaseActivity
import com.todo.app.databinding.ActivityHomeBinding
import com.todo.app.modules.home.`data`.viewmodel.HomeVM
import com.todo.app.modules.personality.ui.PersonalityActivity
import com.todo.app.modules.settings.ui.SettingsActivity
import com.todo.app.modules.worktodays.ui.WorkTodaySActivity
import kotlin.String
import kotlin.Unit

public class HomeActivity : BaseActivity<ActivityHomeBinding>(R.layout.activity_home) {
  private val viewModel: HomeVM by viewModels<HomeVM>()

  public override fun setUpClicks(): Unit {
    binding.linear4.setOnClickListener {

              val destIntent = SettingsActivity.getIntent(this, null)
              startActivity(destIntent)

            }
    binding.linear3.setOnClickListener {

              val destIntent = WorkTodaySActivity.getIntent(this, null)
              startActivity(destIntent)

            }
    binding.linear2.setOnClickListener {

              val destIntent = PersonalityActivity.getIntent(this, null)
              startActivity(destIntent)

            }
  }

  public override fun onInitialized(): Unit {
    binding.homeVM = viewModel
  }

  public companion object {
    public const val TAG: String = "HOME_ACTIVITY"

    public fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, HomeActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
