package com.todo.app.modules.worktodays.`data`.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.todo.app.modules.worktodays.`data`.model.WorkTodayS1RowModel
import com.todo.app.modules.worktodays.`data`.model.WorkTodaySModel
import kotlin.collections.MutableList

public class WorkTodaySVM : ViewModel() {
  public val workTodaySModel: MutableLiveData<WorkTodaySModel> = MutableLiveData(WorkTodaySModel())

  public val recyclerViewList: MutableLiveData<MutableList<WorkTodayS1RowModel>> =
      MutableLiveData(mutableListOf())
}
