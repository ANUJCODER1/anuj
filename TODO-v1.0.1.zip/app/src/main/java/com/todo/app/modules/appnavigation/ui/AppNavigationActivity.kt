package com.todo.app.modules.appnavigation.ui

import androidx.activity.viewModels
import com.todo.app.R
import com.todo.app.appcomponents.base.BaseActivity
import com.todo.app.databinding.ActivityAppNavigationBinding
import com.todo.app.modules.appnavigation.`data`.viewmodel.AppNavigationVM
import com.todo.app.modules.forgotpassword.ui.ForgotPasswordActivity
import com.todo.app.modules.home.ui.HomeActivity
import com.todo.app.modules.language.ui.LanguageActivity
import com.todo.app.modules.login.ui.LoginActivity
import com.todo.app.modules.loginsignup.ui.LoginSignupActivity
import com.todo.app.modules.personality.ui.PersonalityActivity
import com.todo.app.modules.settings.ui.SettingsActivity
import com.todo.app.modules.signup.ui.SignupActivity
import com.todo.app.modules.splash.ui.SplashActivity
import com.todo.app.modules.termsandconditions.ui.TermsandconditionsActivity
import com.todo.app.modules.wishlist.ui.WishListActivity
import com.todo.app.modules.worktodays.ui.WorkTodaySActivity
import kotlin.String
import kotlin.Unit

public class AppNavigationActivity :
    BaseActivity<ActivityAppNavigationBinding>(R.layout.activity_app_navigation) {
  private val viewModel: AppNavigationVM by viewModels<AppNavigationVM>()

  public override fun setUpClicks(): Unit {
    binding.linear13.setOnClickListener {

      val destIntent = SignupActivity.getIntent(this, null)
      startActivity(destIntent)

    }
    binding.linear9.setOnClickListener {

      val destIntent = SettingsActivity.getIntent(this, null)
      startActivity(destIntent)

    }
    binding.linear12.setOnClickListener {

      val destIntent = PersonalityActivity.getIntent(this, null)
      startActivity(destIntent)

    }
    binding.linear6.setOnClickListener {

      val destIntent = ForgotPasswordActivity.getIntent(this, null)
      startActivity(destIntent)

    }
    binding.linear7.setOnClickListener {

      val destIntent = WorkTodaySActivity.getIntent(this, null)
      startActivity(destIntent)

    }
    binding.linear10.setOnClickListener {

      val destIntent = LanguageActivity.getIntent(this, null)
      startActivity(destIntent)

    }
    binding.linear11.setOnClickListener {

      val destIntent = HomeActivity.getIntent(this, null)
      startActivity(destIntent)

    }
    binding.linear8.setOnClickListener {

      val destIntent = WishListActivity.getIntent(this, null)
      startActivity(destIntent)

    }
    binding.linear3.setOnClickListener {

      val destIntent = SplashActivity.getIntent(this, null)
      startActivity(destIntent)

    }
    binding.linear14.setOnClickListener {

      val destIntent = TermsandconditionsActivity.getIntent(this, null)
      startActivity(destIntent)

    }
    binding.linear4.setOnClickListener {

      val destIntent = LoginSignupActivity.getIntent(this, null)
      startActivity(destIntent)

    }
    binding.linear5.setOnClickListener {

      val destIntent = LoginActivity.getIntent(this, null)
      startActivity(destIntent)

    }
  }

  public override fun onInitialized(): Unit {
    binding.appNavigationVM = viewModel
  }

  public companion object {
    public const val TAG: String = "APP_NAVIGATION_ACTIVITY"
  }
}
