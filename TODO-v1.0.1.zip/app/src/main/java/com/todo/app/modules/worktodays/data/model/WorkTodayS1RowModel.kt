package com.todo.app.modules.worktodays.`data`.model

import com.todo.app.R
import com.todo.app.appcomponents.di.MyApp
import kotlin.String

public data class WorkTodayS1RowModel(
  /**
   * TODO Replace with dynamic value
   */
  public var txtResearchProduc: String? =
      MyApp.getInstance().resources.getString(R.string.msg_research_produc)

)
